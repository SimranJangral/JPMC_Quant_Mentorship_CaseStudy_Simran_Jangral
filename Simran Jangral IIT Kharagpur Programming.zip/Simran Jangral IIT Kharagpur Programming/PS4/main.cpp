#include<bits/stdc++.h>
using namespace std;
using lli = long long;
const lli mod = 1e9 + 7;
#define int lli
#define dbg cout<<"Here"<<endl;
#define state pair<int,double>
#define f first
#define s second

int n,k;
vector<vector<state>>graph;

// map<vector<int>,int>nex;
int nex[101][101][101];// stores the next node which gives optimal soln

double rec(int level,int cnt,int st,vector<vector<vector<double>>>&dp){
    // base condition
    if(cnt == k){
        if(level == st){
            return 1;
        }
        return 0;   
    }

    // prunning

    // cache chekc
    if(dp[level][cnt][st] != -1){
        return dp[level][cnt][st];
    }

    // transition
    double ans = 0;
    for(auto ee : graph[level]){
        int e = ee.f;
        double wt = ee.s;
        double re = rec(e,cnt +  1, st,dp)*wt;
        if(re > ans){
            nex[level][cnt][st] = e;
        }
        ans = max(ans,rec(e,cnt+1,st,dp)*wt);
    }


    // save and return
    return dp[level][cnt][st] = ans;

}

void solve(){
//    inputs
    int m;
    cin>>k>>m;

    vector<vector<string>>edge(m,vector<string>(2));
    vector<double>data(m);

    set<string>st;


    for(int i = 0;i<m;i++){
        cin>>edge[i][0]>>edge[i][1];
        cin>>data[i];
        st.insert(edge[i][0]);
        st.insert(edge[i][1]);
    }

    int cnt = 0;
    map<string,int>mp;
    map<int,string>mpr;

    // graph mapping
    for(auto x : st){
        cnt++;
        mp[x] = cnt;
        mpr[cnt] = x;
    }

    // forming graph
    n = cnt;
    graph.resize(n + 1);

    for(int i = 0;i<m;i++){
        int u = mp[edge[i][0]], v = mp[edge[i][1]];
        double wt = data[i];

        graph[u].push_back({v,wt});
        graph[v].push_back({u,1/wt});
    }

    double ans = 0;

    // initialising dp table
    vector<vector<vector<double>>> dp(n+10,vector<vector<double>>(k+10,vector<double>(n+10,-1)));

    // finding max and and starting node of loop
    int stt = 0;
    for(int i = 1;i<=n;i++){
        double re = rec(i,0,i,dp);
        if(re > ans ){
            stt = i;
        }

        ans = max(ans , re);
    }

    if(ans == 0){
        cout<<"No cycle of given requirement exists"<<endl;
        return;
    }

    // printing the loop
    int currlevel = stt;
    cnt = 0;

    while(k--){
        cout<<mpr[currlevel]<<" ";
        currlevel = nex[currlevel][cnt][stt];
        cnt++;
    }
    cout<<mpr[stt]<<endl;
    // cout<<ans<<endl;
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t;
    cin>>t;
    while(t--){
        graph.clear();
        solve();
    }
}
