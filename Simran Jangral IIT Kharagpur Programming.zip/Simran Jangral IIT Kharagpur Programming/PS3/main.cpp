#include<bits/stdc++.h>
using namespace std;

// Bellman-Ford algorithm modifies to detect arbitrage and output the cycle

bool bellmanFord(vector<pair<int,double>> graph[], int src, map<int,string> node_to_cur, int n, vector<vector<double>> edge_wt){

    // dp array to store the minimum cost to reach each node
    vector<double> dp(n+1, INT_MAX);
    int found = 0;
    dp[src] = 0;

    vector<int> par(n,-1);// Array to store the parent of each node in the shortest path

    //Relax all edges n-1 times(standard Bellman-Ford relaxations step)
    for(int i=0; i<n-1; i++){
        for(int j=0; j<n; j++){
            for(auto it:graph[j]){
                //Relax the edge if a shorter path is found
                if(dp[j] + it.second < dp[it.first]){
                    dp[it.first] = dp[j] + it.second;
                    par[it.first] = j;// Update the parent of the node
                }
            }
        }
    }

    // Check for negative-weight cycles(arbitrage opportunities)
    for(int j=0; j<n; j++){
        for(auto it:graph[j]){
            if(dp[j] + it.second < dp[it.first]){
                dp[it.first] = dp[j] + it.second;
                par[it.first] = j;
                int cur = it.first;
                vector<int> ans;
                for(int i=0; i<n; i++) cur = par[cur];// Backtrack to find the cycle
                ans.push_back(cur);
                int new_cur = par[cur];
                while(new_cur != cur){
                    ans.push_back(new_cur);
                    new_cur = par[new_cur];
                }
                ans.push_back(cur);
                // Reverse the cycle path ot show it from start to end
                reverse(ans.begin(), ans.end());
                //check if the sum of logartithms of exchange rates indicates arbitrage
                double sum = 0;
                for(int i=0; i<ans.size()-1; i++){
                    sum += edge_wt[ans[i]][ans[i+1]];
                }
                if(sum <= -1.0*log(1.001)){
                    //Output the currency cycle forming the arbitrage
                    for(auto it:ans) cout<<node_to_cur[it]<<" ";
                    cout<<endl;
                    return 1; // If arbitrage cycle is found
                }
            }
        }
    }

    return 0;
}

void f(){
    int n;
    cin>>n;
    map<pair<string,string>, double> adj;
    for(int i=0; i<n; i++){
        string u,v;
        double exchange_rate;
        cin>>u>>v; // Input source, destination
        cin>>exchange_rate;
        adj[{u,v}] = exchange_rate;
    }
    for(auto it:adj){
        if(adj.find({it.first.second, it.first.first}) == adj.end()){
            adj[{it.first.second, it.first.first}] = 1.0/it.second;
        }
    }

    for(auto& ele:adj){
        ele.second = -1.0 * log(ele.second);
    }
    //converting currency code and nodes indicies
    map<string, int> cur_to_node;
    map<int,string> node_to_cur;
    int cnt = 0;
    // Convert currency codes to unique node indicies
    for(auto it:adj){
        if(cur_to_node.find(it.first.first) == cur_to_node.end()){
            cur_to_node[it.first.first] = cnt++;
            node_to_cur[cnt-1] = it.first.first;
        }
        if(cur_to_node.find(it.first.second) == cur_to_node.end()){
            cur_to_node[it.first.second] = cnt++;
            node_to_cur[cnt-1] = it.first.second;
        }
    }

    //Create a matrix for edge weights
    vector<vector<double>> edge_wt(cnt, vector<double>(cnt, INT_MAX));
    for(auto it:adj){
        edge_wt[cur_to_node[it.first.first]][cur_to_node[it.first.second]] = it.second;
    }
    // Create an adjacency list for the graph
    vector<pair<int,double>> graph[cnt];
    for(auto it:adj){
        graph[cur_to_node[it.first.first]].push_back({cur_to_node[it.first.second], it.second});
    }
    int cycleExists = 0;
    cycleExists = bellmanFord(graph, 0, node_to_cur, cnt, edge_wt);

    if(!cycleExists) cout<<"NO"<<endl;
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int tt;
    cin>>tt;
    while(tt--) f();
    return 0;
}