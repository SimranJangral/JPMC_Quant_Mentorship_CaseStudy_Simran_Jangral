#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'

//  BELLMAN FORD algorithm (to calculate best FX rate to convert currency i to every other currency)
void bellman_ford(int i, int n, vector<vector<double>> &best_conversion_rates, vector<pair<int, int>> &currency_conversion_pairs, vector<vector<double>> &exchange_rate, vector<vector<double>> &commission_rate)
{

    //  Conversion to self is trivial
    best_conversion_rates[i][i] = 1;

    //  Relaxing all edges n-1 times
    for (int jj = 0; jj < n - 1; jj++)
    {
        for (auto currency_pair : currency_conversion_pairs)
        {
            //  Update each pair if possible
            int currency1 = currency_pair.first;
            int currency2 = currency_pair.second;

            //  Conversion from i to currency 2 via currency 1 (only if i to currency 1 is possible)
            if (best_conversion_rates[i][currency1] != -1)
            {
                //  Store k as Best Conversion from i to currency 1
                double k = best_conversion_rates[i][currency1];

                //  Exchange return for currency 1 to currency 2
                double exchange = k * exchange_rate[currency1][currency2];

                //  Final return after deducting commission
                double final = exchange - 0.01 * commission_rate[currency1][currency2] * exchange;

                //  Update best rates
                best_conversion_rates[i][currency2] = max(best_conversion_rates[i][currency2], final);
            }
        }
    }
}

// Function to output result of each query
void query_result(map<string, int> &node_number, vector<vector<double>> &best_conversion_rates)
{
    //  Taking input of queries
    string cur1, cur2;
    cin >> cur1 >> cur2;

    //  If any of the query inputs is not mapped, it implies the currency is not in the graph, so return -1
    if (node_number.find(cur1) == node_number.end() || node_number.find(cur2) == node_number.end())
    {
        cout << -1 << endl;
    }

    //  If query inputs are valid graph nodes, output best conversion rate for the pair
    else
    {
        //  Get mapped value for currencies
        int x = node_number[cur1];
        int y = node_number[cur2];

        //  OUTPUT (with specified precision)
        cout << fixed << setprecision(6);
        double ans = best_conversion_rates[x][y];

        //  Rounding off the answer
        ans = round(ans * 1000000.0) / 1000000.0;
        cout << ans << endl;
    }
}
int32_t main()
{
    //  Input number of test cases
    int t;
    cin >> t;

    while (t--)
    {
        //  Input number of queries and given rates
        int queries, fx_rows;
        cin >> queries >> fx_rows;

        //  Mapping currencies to integers
        map<string, int> node_number;

        //  Constructing vectors for storing given conversions and rates
        vector<vector<double>> commission_rate(500, vector<double>(500));
        vector<vector<double>> exchange_rate(500, vector<double>(500));
        vector<pair<int, int>> currency_conversion_pairs;

        //  Storing total nodes
        int total_nodes = 0;

        //  INPUT
        for (int i = 0; i < fx_rows; i++)
        {
            string currency1, currency2;
            cin >> currency1 >> currency2;

            //  Mapping currencies to integers for graph construction if not already mapped
            if (node_number.find(currency1) == node_number.end())
            {
                node_number[currency1] = total_nodes + 1;

                //  Increment total nodes if a new currency shows up
                total_nodes++;
            }
            if (node_number.find(currency2) == node_number.end())
            {
                node_number[currency2] = total_nodes + 1;

                //  Increment total nodes if a new currency shows up
                total_nodes++;
            }

            //  Push the new pair in the vector
            currency_conversion_pairs.push_back(make_pair(node_number[currency1], node_number[currency2]));

            //  Input exchange and commission rates for the new pair
            double exchange, commission;
            cin >> exchange >> commission;

            commission_rate[node_number[currency1]][node_number[currency2]] = commission;

            exchange_rate[node_number[currency1]][node_number[currency2]] = exchange;
        }

        //  Store total_nodes as n
        int n = total_nodes;

        //  Create vector to store answer(s) for queries
        vector<vector<double>> best_conversion_rates(n + 1, vector<double>(n + 1, -1));

        for (int cur = 1; cur <= n; cur++)
        {
            //  For each currency from 1 to n, calculate best conversion rate to every other currency using BELLMAN FORD ALGORITHM
            bellman_ford(cur, n, best_conversion_rates, currency_conversion_pairs, exchange_rate, commission_rate);
        }

        //  Answer queries
        while (queries--)
        {
            query_result(node_number, best_conversion_rates);
        }
    }
}