#include<bits/stdc++.h>
using namespace std;

//function to process exchange rates and convert them into logarithmic weights
void f(){
    int n;
    cin>>n; // number of exchange rate pairs

    map<pair<string,string>, double> adj; // mapping to store exchange rates between currency pairs

    //Input exchange rates and store them in the map
    for(int i=0; i<n; i++){
        string u,v;
        double exchange_rate;
        cin>>u>>v; // Input currency pair
        cin>>exchange_rate; //Input exchange rate
        adj[{u,v}] = exchange_rate;
    }

    // To ensure the inverse rate is present in the map
    for(auto it:adj){
        if(adj.find({it.first.second, it.first.first}) != adj.end()) continue;
        adj[{it.first.second, it.first.first}] = 1.0/it.second;
    }

    // Convert exhange rates to their negative logarithmic weights
    for(auto& ele:adj){
        ele.second = -1.0 * log(ele.second);
    }

    //Output the adjusted exchnage rate map
    for(auto ele:adj){
        cout << ele.first.first << " " << ele.first.second << " " << fixed << setprecision(6) << ele.second << endl;
    }
    cout<<endl;
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int tt;
    cin>>tt; // Number of test cases
    while(tt--) f();// process each test case
    return 0;
}