#include<bits/stdc++.h>
using namespace std;

// Creating a function to run the Bellman-Ford algorithm, returns true if there is a negative weight cycle in the graph
bool bellmanFord(vector<pair<int,double>> graph[], int n){
    vector<double> dp(n, INT_MAX); // Initialize distance array with maximum values
    dp[0] = 0;
    for(int i=0; i<n-1; i++){
        for(int j=0; j<n; j++){
            for(auto it:graph[j]){
                if(dp[j] + it.second < dp[it.first]){
                    dp[it.first] = dp[j] + it.second;
                }
            }
        }
    }

    //check for negative weight cycles
    for(int j=0; j<n; j++){
        for(auto it:graph[j]){
            if(dp[j] + it.second < dp[it.first]){
                return true;
            }
        }
    }
    return false;
}

//function to process a single test case
void f(){
    int n;
    cin>>n;// number of currency exchange rates
    map<pair<string,string>, double> adj;// map to store exchange rates

    // input exchnage rates and store in adjacency map
    for(int i=0; i<n; i++){
        string u,v;
        double exchange_rate;
        cin>>u>>v;
        cin>>exchange_rate;
        adj[{u,v}] = exchange_rate;
    }
    //Add inverse exchange rates if missing
    for(auto it:adj){
        if(adj.find({it.first.second, it.first.first}) == adj.end()){
            adj[{it.first.second, it.first.first}] = 1.0/it.second;
        }
    }

    // map to convert currency codes to unique node indices
    map<string, int> cur_to_node;
    int cnt = 0;
    for(auto it:adj){
        if(cur_to_node.find(it.first.first) == cur_to_node.end()){
            cur_to_node[it.first.first] = cnt++;
        }
        if(cur_to_node.find(it.first.second) == cur_to_node.end()){
            cur_to_node[it.first.second] = cnt++;
        }
    }

    vector<pair<int,double>> graph[cnt];
    for(auto it:adj){
        graph[cur_to_node[it.first.first]].push_back({cur_to_node[it.first.second], it.second});
    }

    //Check for negative weight cycles using Bellman-Ford
    bool containsNeg = bellmanFord(graph, cnt);
    if(containsNeg) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int tt;
    cin>>tt;
    while(tt--) f();
    return 0;
}